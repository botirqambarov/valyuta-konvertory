"""Default (embedded) Gemini API kalit.

Бу файл иловага қўшилади ва клиентларга ўзи API кэлит киритмасдан
ишлаш имкониятини беради. Қуйидаги қаторни ўз Gemini API key
билан алмаштиринг (https://aistudio.google.com/app/apikey).

Бўш қолдирсангиз — клиент GUI орқали ўзининг кэлитини
киритиши шарт бўлади.

ЭСКАРТМА: Бу файлни git'га юкламанг — `.gitignore` да турипти.
"""
DEFAULT_GEMINI_API_KEY = ""
